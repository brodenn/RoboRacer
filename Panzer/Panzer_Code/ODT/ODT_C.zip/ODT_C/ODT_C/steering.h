// steering.h
#ifndef STEERING_H
#define STEERING_H

#include <Arduino.h>

// Korrektionsfunktion som justerar motorhastigheter baserat på VL53-avstånd
void correctCourse();

#endif
